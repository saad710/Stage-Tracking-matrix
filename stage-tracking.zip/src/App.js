import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

const ZOHO = window.ZOHO;

function App() {
  const [zohoInitialized, setZohoInitialized] = useState(false);
  const [entity, setEntity] = useState("");
  const [entityId, setEntityId] = useState("");
  const [stageHistory, setStageHistory] = useState([]);
  useEffect(()=> {
    /*
    * Subscribe to the EmbeddedApp onPageLoad event before initializing 
    */
    
    ZOHO.embeddedApp.on("PageLoad",function(data)
    {
      console.log(data);
      setEntity(data.Entity);
      setEntityId(data.EntityId)
      //Custom Bussiness logic goes here
    })

    /*
    * initializing the widget.
    */
    ZOHO.embeddedApp.init().then( () => {
      setZohoInitialized(true);
    });
  }, [])

  useEffect(async () => {
    if(zohoInitialized && entity !== "" && entityId !== ""){
      const stageHistoryResp = await ZOHO.CRM.API.getRelatedRecords({Entity:entity,RecordID:entityId,RelatedList:"Stage_History",page:1,per_page:200})
      console.log("Related List Data", stageHistory)
      setStageHistory(stageHistoryResp?.data);
    }

  }, [zohoInitialized, entity, entityId])

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
